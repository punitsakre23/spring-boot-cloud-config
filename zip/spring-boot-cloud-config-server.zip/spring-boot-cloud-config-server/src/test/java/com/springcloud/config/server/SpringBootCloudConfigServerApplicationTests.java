package com.springcloud.config.server;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootCloudConfigServerApplicationTests {

	@Test
	void contextLoads() {
	}

}
