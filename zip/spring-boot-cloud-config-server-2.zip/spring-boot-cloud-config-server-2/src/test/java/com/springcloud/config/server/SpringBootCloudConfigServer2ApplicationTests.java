package com.springcloud.config.server;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootCloudConfigServer2ApplicationTests {

	@Test
	void contextLoads() {
	}

}
