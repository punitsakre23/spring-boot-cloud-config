package com.springcloud.config.server;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootCloudConfigServer2Application {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootCloudConfigServer2Application.class, args);
	}

}
